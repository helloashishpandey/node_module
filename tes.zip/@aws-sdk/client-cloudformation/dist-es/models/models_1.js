import { CloudFormationServiceException as __BaseException } from "./CloudFormationServiceException";
export const ResourceSignalStatus = {
    FAILURE: "FAILURE",
    SUCCESS: "SUCCESS",
};
export class ResourceScanLimitExceededException extends __BaseException {
    constructor(opts) {
        super({
            name: "ResourceScanLimitExceededException",
            $fault: "client",
            ...opts,
        });
        this.name = "ResourceScanLimitExceededException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ResourceScanLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
