import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ListStackInstancesInput,
  ListStackInstancesOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListStackInstancesCommandInput
  extends ListStackInstancesInput {}
export interface ListStackInstancesCommandOutput
  extends ListStackInstancesOutput,
    __MetadataBearer {}
declare const ListStackInstancesCommand_base: {
  new (
    input: ListStackInstancesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackInstancesCommandInput,
    ListStackInstancesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListStackInstancesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackInstancesCommandInput,
    ListStackInstancesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListStackInstancesCommand extends ListStackInstancesCommand_base {}
