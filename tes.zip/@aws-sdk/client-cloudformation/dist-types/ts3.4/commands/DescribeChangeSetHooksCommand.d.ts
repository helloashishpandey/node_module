import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeChangeSetHooksInput,
  DescribeChangeSetHooksOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeChangeSetHooksCommandInput
  extends DescribeChangeSetHooksInput {}
export interface DescribeChangeSetHooksCommandOutput
  extends DescribeChangeSetHooksOutput,
    __MetadataBearer {}
declare const DescribeChangeSetHooksCommand_base: {
  new (
    input: DescribeChangeSetHooksCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeChangeSetHooksCommandInput,
    DescribeChangeSetHooksCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: DescribeChangeSetHooksCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeChangeSetHooksCommandInput,
    DescribeChangeSetHooksCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeChangeSetHooksCommand extends DescribeChangeSetHooksCommand_base {}
