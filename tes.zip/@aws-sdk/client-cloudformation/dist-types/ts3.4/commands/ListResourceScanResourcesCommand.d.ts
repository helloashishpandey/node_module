import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ListResourceScanResourcesInput,
  ListResourceScanResourcesOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListResourceScanResourcesCommandInput
  extends ListResourceScanResourcesInput {}
export interface ListResourceScanResourcesCommandOutput
  extends ListResourceScanResourcesOutput,
    __MetadataBearer {}
declare const ListResourceScanResourcesCommand_base: {
  new (
    input: ListResourceScanResourcesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListResourceScanResourcesCommandInput,
    ListResourceScanResourcesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListResourceScanResourcesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListResourceScanResourcesCommandInput,
    ListResourceScanResourcesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListResourceScanResourcesCommand extends ListResourceScanResourcesCommand_base {}
