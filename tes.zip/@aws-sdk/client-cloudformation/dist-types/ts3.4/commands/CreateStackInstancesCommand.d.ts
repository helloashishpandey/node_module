import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  CreateStackInstancesInput,
  CreateStackInstancesOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface CreateStackInstancesCommandInput
  extends CreateStackInstancesInput {}
export interface CreateStackInstancesCommandOutput
  extends CreateStackInstancesOutput,
    __MetadataBearer {}
declare const CreateStackInstancesCommand_base: {
  new (
    input: CreateStackInstancesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateStackInstancesCommandInput,
    CreateStackInstancesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: CreateStackInstancesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateStackInstancesCommandInput,
    CreateStackInstancesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CreateStackInstancesCommand extends CreateStackInstancesCommand_base {}
