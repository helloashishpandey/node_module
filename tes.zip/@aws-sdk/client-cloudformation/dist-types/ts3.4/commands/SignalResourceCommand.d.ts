import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { SignalResourceInput } from "../models/models_1";
export { __MetadataBearer, $Command };
export interface SignalResourceCommandInput extends SignalResourceInput {}
export interface SignalResourceCommandOutput extends __MetadataBearer {}
declare const SignalResourceCommand_base: {
  new (
    input: SignalResourceCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    SignalResourceCommandInput,
    SignalResourceCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: SignalResourceCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    SignalResourceCommandInput,
    SignalResourceCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class SignalResourceCommand extends SignalResourceCommand_base {}
