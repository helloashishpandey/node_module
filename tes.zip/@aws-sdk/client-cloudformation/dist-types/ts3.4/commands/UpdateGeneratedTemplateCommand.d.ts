import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  UpdateGeneratedTemplateInput,
  UpdateGeneratedTemplateOutput,
} from "../models/models_1";
export { __MetadataBearer, $Command };
export interface UpdateGeneratedTemplateCommandInput
  extends UpdateGeneratedTemplateInput {}
export interface UpdateGeneratedTemplateCommandOutput
  extends UpdateGeneratedTemplateOutput,
    __MetadataBearer {}
declare const UpdateGeneratedTemplateCommand_base: {
  new (
    input: UpdateGeneratedTemplateCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateGeneratedTemplateCommandInput,
    UpdateGeneratedTemplateCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: UpdateGeneratedTemplateCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateGeneratedTemplateCommandInput,
    UpdateGeneratedTemplateCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class UpdateGeneratedTemplateCommand extends UpdateGeneratedTemplateCommand_base {}
