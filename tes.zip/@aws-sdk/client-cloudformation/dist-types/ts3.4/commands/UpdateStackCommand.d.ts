import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { UpdateStackInput, UpdateStackOutput } from "../models/models_1";
export { __MetadataBearer, $Command };
export interface UpdateStackCommandInput extends UpdateStackInput {}
export interface UpdateStackCommandOutput
  extends UpdateStackOutput,
    __MetadataBearer {}
declare const UpdateStackCommand_base: {
  new (
    input: UpdateStackCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateStackCommandInput,
    UpdateStackCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: UpdateStackCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateStackCommandInput,
    UpdateStackCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class UpdateStackCommand extends UpdateStackCommand_base {}
