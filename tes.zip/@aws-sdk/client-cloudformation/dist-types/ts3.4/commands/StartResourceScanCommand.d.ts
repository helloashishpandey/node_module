import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  StartResourceScanInput,
  StartResourceScanOutput,
} from "../models/models_1";
export { __MetadataBearer, $Command };
export interface StartResourceScanCommandInput extends StartResourceScanInput {}
export interface StartResourceScanCommandOutput
  extends StartResourceScanOutput,
    __MetadataBearer {}
declare const StartResourceScanCommand_base: {
  new (
    input: StartResourceScanCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    StartResourceScanCommandInput,
    StartResourceScanCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [StartResourceScanCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    StartResourceScanCommandInput,
    StartResourceScanCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class StartResourceScanCommand extends StartResourceScanCommand_base {}
