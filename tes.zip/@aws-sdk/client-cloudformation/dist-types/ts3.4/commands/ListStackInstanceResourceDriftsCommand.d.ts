import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ListStackInstanceResourceDriftsInput,
  ListStackInstanceResourceDriftsOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListStackInstanceResourceDriftsCommandInput
  extends ListStackInstanceResourceDriftsInput {}
export interface ListStackInstanceResourceDriftsCommandOutput
  extends ListStackInstanceResourceDriftsOutput,
    __MetadataBearer {}
declare const ListStackInstanceResourceDriftsCommand_base: {
  new (
    input: ListStackInstanceResourceDriftsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackInstanceResourceDriftsCommandInput,
    ListStackInstanceResourceDriftsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListStackInstanceResourceDriftsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackInstanceResourceDriftsCommandInput,
    ListStackInstanceResourceDriftsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListStackInstanceResourceDriftsCommand extends ListStackInstanceResourceDriftsCommand_base {}
