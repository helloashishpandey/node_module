import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeStackEventsInput,
  DescribeStackEventsOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeStackEventsCommandInput
  extends DescribeStackEventsInput {}
export interface DescribeStackEventsCommandOutput
  extends DescribeStackEventsOutput,
    __MetadataBearer {}
declare const DescribeStackEventsCommand_base: {
  new (
    input: DescribeStackEventsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeStackEventsCommandInput,
    DescribeStackEventsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeStackEventsCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeStackEventsCommandInput,
    DescribeStackEventsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeStackEventsCommand extends DescribeStackEventsCommand_base {}
