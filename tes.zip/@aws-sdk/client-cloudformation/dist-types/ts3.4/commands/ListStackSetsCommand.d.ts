import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { ListStackSetsInput, ListStackSetsOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListStackSetsCommandInput extends ListStackSetsInput {}
export interface ListStackSetsCommandOutput
  extends ListStackSetsOutput,
    __MetadataBearer {}
declare const ListStackSetsCommand_base: {
  new (
    input: ListStackSetsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackSetsCommandInput,
    ListStackSetsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListStackSetsCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackSetsCommandInput,
    ListStackSetsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListStackSetsCommand extends ListStackSetsCommand_base {}
