import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { CreateStackSetInput, CreateStackSetOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface CreateStackSetCommandInput extends CreateStackSetInput {}
export interface CreateStackSetCommandOutput
  extends CreateStackSetOutput,
    __MetadataBearer {}
declare const CreateStackSetCommand_base: {
  new (
    input: CreateStackSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateStackSetCommandInput,
    CreateStackSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: CreateStackSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateStackSetCommandInput,
    CreateStackSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CreateStackSetCommand extends CreateStackSetCommand_base {}
