import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { ListStacksInput, ListStacksOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListStacksCommandInput extends ListStacksInput {}
export interface ListStacksCommandOutput
  extends ListStacksOutput,
    __MetadataBearer {}
declare const ListStacksCommand_base: {
  new (
    input: ListStacksCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStacksCommandInput,
    ListStacksCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListStacksCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    ListStacksCommandInput,
    ListStacksCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListStacksCommand extends ListStacksCommand_base {}
