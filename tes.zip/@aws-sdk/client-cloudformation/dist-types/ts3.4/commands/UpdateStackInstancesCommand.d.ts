import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  UpdateStackInstancesInput,
  UpdateStackInstancesOutput,
} from "../models/models_1";
export { __MetadataBearer, $Command };
export interface UpdateStackInstancesCommandInput
  extends UpdateStackInstancesInput {}
export interface UpdateStackInstancesCommandOutput
  extends UpdateStackInstancesOutput,
    __MetadataBearer {}
declare const UpdateStackInstancesCommand_base: {
  new (
    input: UpdateStackInstancesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateStackInstancesCommandInput,
    UpdateStackInstancesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: UpdateStackInstancesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateStackInstancesCommandInput,
    UpdateStackInstancesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class UpdateStackInstancesCommand extends UpdateStackInstancesCommand_base {}
