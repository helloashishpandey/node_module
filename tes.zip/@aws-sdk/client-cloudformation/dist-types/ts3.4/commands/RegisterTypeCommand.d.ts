import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { RegisterTypeInput, RegisterTypeOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface RegisterTypeCommandInput extends RegisterTypeInput {}
export interface RegisterTypeCommandOutput
  extends RegisterTypeOutput,
    __MetadataBearer {}
declare const RegisterTypeCommand_base: {
  new (
    input: RegisterTypeCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    RegisterTypeCommandInput,
    RegisterTypeCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: RegisterTypeCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    RegisterTypeCommandInput,
    RegisterTypeCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class RegisterTypeCommand extends RegisterTypeCommand_base {}
