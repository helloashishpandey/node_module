import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeStackSetOperationInput,
  DescribeStackSetOperationOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeStackSetOperationCommandInput
  extends DescribeStackSetOperationInput {}
export interface DescribeStackSetOperationCommandOutput
  extends DescribeStackSetOperationOutput,
    __MetadataBearer {}
declare const DescribeStackSetOperationCommand_base: {
  new (
    input: DescribeStackSetOperationCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeStackSetOperationCommandInput,
    DescribeStackSetOperationCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: DescribeStackSetOperationCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeStackSetOperationCommandInput,
    DescribeStackSetOperationCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeStackSetOperationCommand extends DescribeStackSetOperationCommand_base {}
