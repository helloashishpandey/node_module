import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeResourceScanInput,
  DescribeResourceScanOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeResourceScanCommandInput
  extends DescribeResourceScanInput {}
export interface DescribeResourceScanCommandOutput
  extends DescribeResourceScanOutput,
    __MetadataBearer {}
declare const DescribeResourceScanCommand_base: {
  new (
    input: DescribeResourceScanCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeResourceScanCommandInput,
    DescribeResourceScanCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: DescribeResourceScanCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeResourceScanCommandInput,
    DescribeResourceScanCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeResourceScanCommand extends DescribeResourceScanCommand_base {}
