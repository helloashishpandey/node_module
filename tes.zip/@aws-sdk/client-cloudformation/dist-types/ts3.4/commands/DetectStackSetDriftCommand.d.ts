import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DetectStackSetDriftInput,
  DetectStackSetDriftOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DetectStackSetDriftCommandInput
  extends DetectStackSetDriftInput {}
export interface DetectStackSetDriftCommandOutput
  extends DetectStackSetDriftOutput,
    __MetadataBearer {}
declare const DetectStackSetDriftCommand_base: {
  new (
    input: DetectStackSetDriftCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DetectStackSetDriftCommandInput,
    DetectStackSetDriftCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: DetectStackSetDriftCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DetectStackSetDriftCommandInput,
    DetectStackSetDriftCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DetectStackSetDriftCommand extends DetectStackSetDriftCommand_base {}
