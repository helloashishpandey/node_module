import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ListStackSetAutoDeploymentTargetsInput,
  ListStackSetAutoDeploymentTargetsOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListStackSetAutoDeploymentTargetsCommandInput
  extends ListStackSetAutoDeploymentTargetsInput {}
export interface ListStackSetAutoDeploymentTargetsCommandOutput
  extends ListStackSetAutoDeploymentTargetsOutput,
    __MetadataBearer {}
declare const ListStackSetAutoDeploymentTargetsCommand_base: {
  new (
    input: ListStackSetAutoDeploymentTargetsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackSetAutoDeploymentTargetsCommandInput,
    ListStackSetAutoDeploymentTargetsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListStackSetAutoDeploymentTargetsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackSetAutoDeploymentTargetsCommandInput,
    ListStackSetAutoDeploymentTargetsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListStackSetAutoDeploymentTargetsCommand extends ListStackSetAutoDeploymentTargetsCommand_base {}
