import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { GetStackPolicyInput, GetStackPolicyOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface GetStackPolicyCommandInput extends GetStackPolicyInput {}
export interface GetStackPolicyCommandOutput
  extends GetStackPolicyOutput,
    __MetadataBearer {}
declare const GetStackPolicyCommand_base: {
  new (
    input: GetStackPolicyCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetStackPolicyCommandInput,
    GetStackPolicyCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: GetStackPolicyCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetStackPolicyCommandInput,
    GetStackPolicyCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class GetStackPolicyCommand extends GetStackPolicyCommand_base {}
