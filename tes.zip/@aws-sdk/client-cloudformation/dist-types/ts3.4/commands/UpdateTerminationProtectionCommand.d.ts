import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  UpdateTerminationProtectionInput,
  UpdateTerminationProtectionOutput,
} from "../models/models_1";
export { __MetadataBearer, $Command };
export interface UpdateTerminationProtectionCommandInput
  extends UpdateTerminationProtectionInput {}
export interface UpdateTerminationProtectionCommandOutput
  extends UpdateTerminationProtectionOutput,
    __MetadataBearer {}
declare const UpdateTerminationProtectionCommand_base: {
  new (
    input: UpdateTerminationProtectionCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateTerminationProtectionCommandInput,
    UpdateTerminationProtectionCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: UpdateTerminationProtectionCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateTerminationProtectionCommandInput,
    UpdateTerminationProtectionCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class UpdateTerminationProtectionCommand extends UpdateTerminationProtectionCommand_base {}
