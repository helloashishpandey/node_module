import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ImportStacksToStackSetInput,
  ImportStacksToStackSetOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ImportStacksToStackSetCommandInput
  extends ImportStacksToStackSetInput {}
export interface ImportStacksToStackSetCommandOutput
  extends ImportStacksToStackSetOutput,
    __MetadataBearer {}
declare const ImportStacksToStackSetCommand_base: {
  new (
    input: ImportStacksToStackSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ImportStacksToStackSetCommandInput,
    ImportStacksToStackSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ImportStacksToStackSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ImportStacksToStackSetCommandInput,
    ImportStacksToStackSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ImportStacksToStackSetCommand extends ImportStacksToStackSetCommand_base {}
