import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { ActivateTypeInput, ActivateTypeOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ActivateTypeCommandInput extends ActivateTypeInput {}
export interface ActivateTypeCommandOutput
  extends ActivateTypeOutput,
    __MetadataBearer {}
declare const ActivateTypeCommand_base: {
  new (
    input: ActivateTypeCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ActivateTypeCommandInput,
    ActivateTypeCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ActivateTypeCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    ActivateTypeCommandInput,
    ActivateTypeCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ActivateTypeCommand extends ActivateTypeCommand_base {}
