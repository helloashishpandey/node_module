import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ListResourceScanRelatedResourcesInput,
  ListResourceScanRelatedResourcesOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListResourceScanRelatedResourcesCommandInput
  extends ListResourceScanRelatedResourcesInput {}
export interface ListResourceScanRelatedResourcesCommandOutput
  extends ListResourceScanRelatedResourcesOutput,
    __MetadataBearer {}
declare const ListResourceScanRelatedResourcesCommand_base: {
  new (
    input: ListResourceScanRelatedResourcesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListResourceScanRelatedResourcesCommandInput,
    ListResourceScanRelatedResourcesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListResourceScanRelatedResourcesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListResourceScanRelatedResourcesCommandInput,
    ListResourceScanRelatedResourcesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListResourceScanRelatedResourcesCommand extends ListResourceScanRelatedResourcesCommand_base {}
