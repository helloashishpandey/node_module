import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { UpdateStackSetInput, UpdateStackSetOutput } from "../models/models_1";
export { __MetadataBearer, $Command };
export interface UpdateStackSetCommandInput extends UpdateStackSetInput {}
export interface UpdateStackSetCommandOutput
  extends UpdateStackSetOutput,
    __MetadataBearer {}
declare const UpdateStackSetCommand_base: {
  new (
    input: UpdateStackSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateStackSetCommandInput,
    UpdateStackSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: UpdateStackSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    UpdateStackSetCommandInput,
    UpdateStackSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class UpdateStackSetCommand extends UpdateStackSetCommand_base {}
