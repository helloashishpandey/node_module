import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { TestTypeInput, TestTypeOutput } from "../models/models_1";
export { __MetadataBearer, $Command };
export interface TestTypeCommandInput extends TestTypeInput {}
export interface TestTypeCommandOutput
  extends TestTypeOutput,
    __MetadataBearer {}
declare const TestTypeCommand_base: {
  new (
    input: TestTypeCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    TestTypeCommandInput,
    TestTypeCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [TestTypeCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    TestTypeCommandInput,
    TestTypeCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class TestTypeCommand extends TestTypeCommand_base {}
