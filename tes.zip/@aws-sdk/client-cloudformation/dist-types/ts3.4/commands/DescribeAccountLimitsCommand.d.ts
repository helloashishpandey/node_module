import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeAccountLimitsInput,
  DescribeAccountLimitsOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeAccountLimitsCommandInput
  extends DescribeAccountLimitsInput {}
export interface DescribeAccountLimitsCommandOutput
  extends DescribeAccountLimitsOutput,
    __MetadataBearer {}
declare const DescribeAccountLimitsCommand_base: {
  new (
    input: DescribeAccountLimitsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeAccountLimitsCommandInput,
    DescribeAccountLimitsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeAccountLimitsCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeAccountLimitsCommandInput,
    DescribeAccountLimitsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeAccountLimitsCommand extends DescribeAccountLimitsCommand_base {}
