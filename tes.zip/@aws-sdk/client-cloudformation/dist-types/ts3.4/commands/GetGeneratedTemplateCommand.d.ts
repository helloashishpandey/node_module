import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  GetGeneratedTemplateInput,
  GetGeneratedTemplateOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface GetGeneratedTemplateCommandInput
  extends GetGeneratedTemplateInput {}
export interface GetGeneratedTemplateCommandOutput
  extends GetGeneratedTemplateOutput,
    __MetadataBearer {}
declare const GetGeneratedTemplateCommand_base: {
  new (
    input: GetGeneratedTemplateCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetGeneratedTemplateCommandInput,
    GetGeneratedTemplateCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: GetGeneratedTemplateCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetGeneratedTemplateCommandInput,
    GetGeneratedTemplateCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class GetGeneratedTemplateCommand extends GetGeneratedTemplateCommand_base {}
