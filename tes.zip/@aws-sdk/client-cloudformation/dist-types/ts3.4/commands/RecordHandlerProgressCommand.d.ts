import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  RecordHandlerProgressInput,
  RecordHandlerProgressOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface RecordHandlerProgressCommandInput
  extends RecordHandlerProgressInput {}
export interface RecordHandlerProgressCommandOutput
  extends RecordHandlerProgressOutput,
    __MetadataBearer {}
declare const RecordHandlerProgressCommand_base: {
  new (
    input: RecordHandlerProgressCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    RecordHandlerProgressCommandInput,
    RecordHandlerProgressCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: RecordHandlerProgressCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    RecordHandlerProgressCommandInput,
    RecordHandlerProgressCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class RecordHandlerProgressCommand extends RecordHandlerProgressCommand_base {}
