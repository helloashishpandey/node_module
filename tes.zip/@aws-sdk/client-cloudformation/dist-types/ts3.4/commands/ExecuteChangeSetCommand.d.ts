import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ExecuteChangeSetInput,
  ExecuteChangeSetOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ExecuteChangeSetCommandInput extends ExecuteChangeSetInput {}
export interface ExecuteChangeSetCommandOutput
  extends ExecuteChangeSetOutput,
    __MetadataBearer {}
declare const ExecuteChangeSetCommand_base: {
  new (
    input: ExecuteChangeSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ExecuteChangeSetCommandInput,
    ExecuteChangeSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ExecuteChangeSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ExecuteChangeSetCommandInput,
    ExecuteChangeSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ExecuteChangeSetCommand extends ExecuteChangeSetCommand_base {}
