import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { CreateStackInput, CreateStackOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface CreateStackCommandInput extends CreateStackInput {}
export interface CreateStackCommandOutput
  extends CreateStackOutput,
    __MetadataBearer {}
declare const CreateStackCommand_base: {
  new (
    input: CreateStackCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateStackCommandInput,
    CreateStackCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: CreateStackCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateStackCommandInput,
    CreateStackCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CreateStackCommand extends CreateStackCommand_base {}
