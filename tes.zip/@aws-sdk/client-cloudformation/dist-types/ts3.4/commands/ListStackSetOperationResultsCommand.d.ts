import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ListStackSetOperationResultsInput,
  ListStackSetOperationResultsOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListStackSetOperationResultsCommandInput
  extends ListStackSetOperationResultsInput {}
export interface ListStackSetOperationResultsCommandOutput
  extends ListStackSetOperationResultsOutput,
    __MetadataBearer {}
declare const ListStackSetOperationResultsCommand_base: {
  new (
    input: ListStackSetOperationResultsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackSetOperationResultsCommandInput,
    ListStackSetOperationResultsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListStackSetOperationResultsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackSetOperationResultsCommandInput,
    ListStackSetOperationResultsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListStackSetOperationResultsCommand extends ListStackSetOperationResultsCommand_base {}
