import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ListTypeRegistrationsInput,
  ListTypeRegistrationsOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListTypeRegistrationsCommandInput
  extends ListTypeRegistrationsInput {}
export interface ListTypeRegistrationsCommandOutput
  extends ListTypeRegistrationsOutput,
    __MetadataBearer {}
declare const ListTypeRegistrationsCommand_base: {
  new (
    input: ListTypeRegistrationsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListTypeRegistrationsCommandInput,
    ListTypeRegistrationsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListTypeRegistrationsCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    ListTypeRegistrationsCommandInput,
    ListTypeRegistrationsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListTypeRegistrationsCommand extends ListTypeRegistrationsCommand_base {}
