import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { SetStackPolicyInput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface SetStackPolicyCommandInput extends SetStackPolicyInput {}
export interface SetStackPolicyCommandOutput extends __MetadataBearer {}
declare const SetStackPolicyCommand_base: {
  new (
    input: SetStackPolicyCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    SetStackPolicyCommandInput,
    SetStackPolicyCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: SetStackPolicyCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    SetStackPolicyCommandInput,
    SetStackPolicyCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class SetStackPolicyCommand extends SetStackPolicyCommand_base {}
