import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { ListTypesInput, ListTypesOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListTypesCommandInput extends ListTypesInput {}
export interface ListTypesCommandOutput
  extends ListTypesOutput,
    __MetadataBearer {}
declare const ListTypesCommand_base: {
  new (
    input: ListTypesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListTypesCommandInput,
    ListTypesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListTypesCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    ListTypesCommandInput,
    ListTypesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListTypesCommand extends ListTypesCommand_base {}
