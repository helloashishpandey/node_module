import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { RollbackStackInput, RollbackStackOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface RollbackStackCommandInput extends RollbackStackInput {}
export interface RollbackStackCommandOutput
  extends RollbackStackOutput,
    __MetadataBearer {}
declare const RollbackStackCommand_base: {
  new (
    input: RollbackStackCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    RollbackStackCommandInput,
    RollbackStackCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: RollbackStackCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    RollbackStackCommandInput,
    RollbackStackCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class RollbackStackCommand extends RollbackStackCommand_base {}
