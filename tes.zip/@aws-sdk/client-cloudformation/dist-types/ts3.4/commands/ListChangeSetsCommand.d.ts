import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { ListChangeSetsInput, ListChangeSetsOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListChangeSetsCommandInput extends ListChangeSetsInput {}
export interface ListChangeSetsCommandOutput
  extends ListChangeSetsOutput,
    __MetadataBearer {}
declare const ListChangeSetsCommand_base: {
  new (
    input: ListChangeSetsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListChangeSetsCommandInput,
    ListChangeSetsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListChangeSetsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListChangeSetsCommandInput,
    ListChangeSetsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListChangeSetsCommand extends ListChangeSetsCommand_base {}
