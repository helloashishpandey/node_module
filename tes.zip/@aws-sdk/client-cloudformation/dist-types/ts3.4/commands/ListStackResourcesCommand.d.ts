import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ListStackResourcesInput,
  ListStackResourcesOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListStackResourcesCommandInput
  extends ListStackResourcesInput {}
export interface ListStackResourcesCommandOutput
  extends ListStackResourcesOutput,
    __MetadataBearer {}
declare const ListStackResourcesCommand_base: {
  new (
    input: ListStackResourcesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackResourcesCommandInput,
    ListStackResourcesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListStackResourcesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackResourcesCommandInput,
    ListStackResourcesCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListStackResourcesCommand extends ListStackResourcesCommand_base {}
