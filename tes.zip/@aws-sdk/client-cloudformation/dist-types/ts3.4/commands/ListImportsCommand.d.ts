import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { ListImportsInput, ListImportsOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListImportsCommandInput extends ListImportsInput {}
export interface ListImportsCommandOutput
  extends ListImportsOutput,
    __MetadataBearer {}
declare const ListImportsCommand_base: {
  new (
    input: ListImportsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListImportsCommandInput,
    ListImportsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListImportsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListImportsCommandInput,
    ListImportsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListImportsCommand extends ListImportsCommand_base {}
