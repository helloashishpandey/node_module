import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ValidateTemplateInput,
  ValidateTemplateOutput,
} from "../models/models_1";
export { __MetadataBearer, $Command };
export interface ValidateTemplateCommandInput extends ValidateTemplateInput {}
export interface ValidateTemplateCommandOutput
  extends ValidateTemplateOutput,
    __MetadataBearer {}
declare const ValidateTemplateCommand_base: {
  new (
    input: ValidateTemplateCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ValidateTemplateCommandInput,
    ValidateTemplateCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ValidateTemplateCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    ValidateTemplateCommandInput,
    ValidateTemplateCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ValidateTemplateCommand extends ValidateTemplateCommand_base {}
