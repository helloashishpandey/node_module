import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  StopStackSetOperationInput,
  StopStackSetOperationOutput,
} from "../models/models_1";
export { __MetadataBearer, $Command };
export interface StopStackSetOperationCommandInput
  extends StopStackSetOperationInput {}
export interface StopStackSetOperationCommandOutput
  extends StopStackSetOperationOutput,
    __MetadataBearer {}
declare const StopStackSetOperationCommand_base: {
  new (
    input: StopStackSetOperationCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    StopStackSetOperationCommandInput,
    StopStackSetOperationCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: StopStackSetOperationCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    StopStackSetOperationCommandInput,
    StopStackSetOperationCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class StopStackSetOperationCommand extends StopStackSetOperationCommand_base {}
