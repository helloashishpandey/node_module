import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { ListExportsInput, ListExportsOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListExportsCommandInput extends ListExportsInput {}
export interface ListExportsCommandOutput
  extends ListExportsOutput,
    __MetadataBearer {}
declare const ListExportsCommand_base: {
  new (
    input: ListExportsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListExportsCommandInput,
    ListExportsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListExportsCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    ListExportsCommandInput,
    ListExportsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListExportsCommand extends ListExportsCommand_base {}
