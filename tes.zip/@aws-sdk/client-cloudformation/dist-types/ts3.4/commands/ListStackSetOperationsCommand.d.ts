import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ListStackSetOperationsInput,
  ListStackSetOperationsOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ListStackSetOperationsCommandInput
  extends ListStackSetOperationsInput {}
export interface ListStackSetOperationsCommandOutput
  extends ListStackSetOperationsOutput,
    __MetadataBearer {}
declare const ListStackSetOperationsCommand_base: {
  new (
    input: ListStackSetOperationsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackSetOperationsCommandInput,
    ListStackSetOperationsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    __0_0: ListStackSetOperationsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListStackSetOperationsCommandInput,
    ListStackSetOperationsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListStackSetOperationsCommand extends ListStackSetOperationsCommand_base {}
